call .\.venv\Scripts\activate.bat
python main.py
deactivate